﻿using AbilityUser;
using Verse;
using TorannMagic;

namespace MF_DLL
{
	public class MF_Spawn : Projectile_Ability
	{
		protected override void Impact(Thing hitThing)
		{
            Pawn P1 = (this.launcher as Pawn);
            Map map = P1.Map;
            IntVec3 position = P1.Position;
            //法晶
            if (this.def == MF_DefOf.MF_Projectile_SpawnCrystal)
            {
                if (P1.story.traits.HasTrait(MF_DefOf.MF_Scholar))
                {
                    CompAbilityUserMagic comp = P1.GetComp<CompAbilityUserMagic>();
                    this.verVal = TM_Calc.GetMagicSkillLevel(P1, comp.MagicData.MagicPowerSkill_Custom, "MF_CondensedCrystal", "_ver", true);
                    this.pwrVal = TM_Calc.GetMagicSkillLevel(P1, comp.MagicData.MagicPowerSkill_Custom, "MF_CondensedCrystal", "_pwr", true);
                    float A = pwrVal * 0.25f;
                    if (Rand.Chance(A))
                    {
                        GenSpawn.Spawn(MF_DefOf.MF_SpecialCrystal, position, map, WipeMode.VanishOrMoveAside);
                        for (int a = 0; a < verVal; a++) 
                    { 
                        GenSpawn.Spawn(MF_DefOf.MF_SpecialCrystal, position, map, WipeMode.VanishOrMoveAside);
                    }
                        }
                        else
                        {
                        GenSpawn.Spawn(MF_DefOf.MF_Crystal, position, map, WipeMode.VanishOrMoveAside);
                        for (int a = 0; a < verVal; a++)
                        {
                            GenSpawn.Spawn(MF_DefOf.MF_Crystal, position, map, WipeMode.VanishOrMoveAside);
                        }
                        }
                    }
                else
                {
                    GenSpawn.Spawn(MF_DefOf.MF_Crystal, position, map, WipeMode.VanishOrMoveAside);
                }
            }
            //法识纸
            if (this.def == MF_DefOf.MF_Projectile_WMTP)
            {
                if (P1.story.traits.HasTrait(MF_DefOf.MF_Scholar))
                {
                    CompAbilityUserMagic comp = P1.GetComp<CompAbilityUserMagic>();
                    this.verVal = TM_Calc.GetMagicSkillLevel(P1, comp.MagicData.MagicPowerSkill_Custom, "MF_WMTP", "_ver", true);
                    this.pwrVal = TM_Calc.GetMagicSkillLevel(P1, comp.MagicData.MagicPowerSkill_Custom, "MF_WMTP", "_pwr", true);
                    float A = pwrVal * 0.25f + 0.25f;
                    verVal++;
                    if (Rand.Chance(A))
                    {
                        for (int a = 0; a < verVal; a++)
                        {
                            GenSpawn.Spawn(MF_DefOf.MF_excellent_Paper, position, map, WipeMode.VanishOrMoveAside);
                        }
                    }
                    else
                    {
                        for (int a = 0; a < verVal; a++)
                        {
                            GenSpawn.Spawn(MF_DefOf.MF_Paper, position, map, WipeMode.VanishOrMoveAside);
                        }
                    }

                }
                else
                {
                    GenSpawn.Spawn(MF_DefOf.MF_Paper, position, map, WipeMode.VanishOrMoveAside);
                }
            }
			base.Destroy(DestroyMode.Vanish);
	}
        private int verVal = 0;
        private int pwrVal = 0;
    }
}
