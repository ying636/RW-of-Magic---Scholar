﻿using RimWorld;
using Verse;
using TorannMagic;

namespace MF_DLL
{
	public class UseEffect2 : CompUseEffect
	{
		public override void DoEffect(Pawn user)
		{
			CompAbilityUserMagic comp = user.GetComp<CompAbilityUserMagic>();
			bool flag2 = comp != null && comp.IsMagicUser;
			if (flag2)
			{
				comp.MagicUserXP += 100;
				this.parent.SplitOff(1).Destroy(DestroyMode.Vanish);
			}

			else
			{
				Messages.Message("这个生物不是法师哟~", MessageTypeDefOf.NegativeEvent, true);
			}
		}
	}
}