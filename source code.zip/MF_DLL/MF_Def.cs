﻿using System;
using RimWorld;
using Verse;
namespace MF_DLL
{
    [DefOf]
    public static class MF_DefOf
    {
        public static ThingDef MF_Crystal;
        public static ThingDef MF_Paper;
        public static ThingDef MF_Projectile_WMTP;
        public static ThingDef MF_Projectile_SpawnCrystal;
        public static ThingDef MF_SpecialCrystal;
        public static TraitDef MF_Scholar;
        public static ThingDef MF_excellent_Paper;
    }
}
